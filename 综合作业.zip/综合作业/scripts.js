let currentIndex = 0;
const images = document.querySelectorAll('.banner-image');
const totalImages = images.length;

function showImage(index) {
    images.forEach((image, idx) => {
        image.style.left = `${(idx - index) * 100}%`;
    });
}

function nextImage() {
    currentIndex = (currentIndex + 1) % totalImages;
    showImage(currentIndex);
}

setInterval(nextImage, 3000); // 每3秒切换一次图片

// 初始化显示第一张图片
showImage(currentIndex);
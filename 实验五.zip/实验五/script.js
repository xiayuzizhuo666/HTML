// 获取表单元素和提示信息元素
const userForm = document.getElementById('userForm');
const messageElement = document.getElementById('message');

// 为表单的提交事件添加监听器
userForm.addEventListener('submit', function (event) {
  event.preventDefault();

  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value.trim();
  const confirmPassword = document.getElementById('confirmPassword').value.trim();

  // 验证函数，返回错误信息字符串，如果验证通过则返回空字符串
  const errorMessage = validateForm(username, password, confirmPassword);
  if (errorMessage) {
    messageElement.textContent = errorMessage;
  } else {
    alert('用户名: ' + username);
    messageElement.textContent = '';
  }
});

// 验证表单数据的函数
function validateForm(username, password, confirmPassword) {
  if (!username) return '用户名不能为空';
  if (!password) return '密码不能为空';
  if (password!== confirmPassword) return '密码和确认密码不一致';
  return '';
}